class CreateBooks < ActiveRecord::Migration[7.0]
  def change
    create_table :books do |t|
      t.string :title
      t.integer :price
      t.text :description
      t.references :subject
      t.timestamps
    end
  end
end
