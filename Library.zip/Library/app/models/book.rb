class Book < ApplicationRecord
	belongs_to :subject
	has_one_attached :book_image
	validates :title,:price,:description,presence:true
	 #Validating Active Storage Image Uploading
    validates :book_image,attached:true, content_type: { in: 'image/jpeg', message: 'image should be jpeg format' },size: { less_than: 1.megabytes , message: 'It should be less than 1 megabyte' }
end
